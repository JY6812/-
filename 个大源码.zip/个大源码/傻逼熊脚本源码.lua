---废物熊脚本源码已被Advanced logic团队破解😎
    local library = loadstring(game:HttpGet("https://raw.githubusercontent.com/IIIlll1ll1/Cracks/main/BearUI.lua", true))()
    local window = library:new("傻逼熊脚本")
    local creds = window:Tab("关于", "6035145364")
    local bin = creds:section("信息", true)
    bin:Label("你的注入器:" .. identifyexecutor())
    bin:Label("更新7月1日")
    bin:Label("qq：1090977142")
    local credits = creds:section("关闭", true)
    credits:Button(
        "关闭脚本",
        function()
            game:GetService("CoreGui")["frosty"]:Destroy()
        end
    )
    local creds = window:Tab("通用", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "玩家加入游戏提示",
        function()
            loadstring(game:HttpGet("https://raw.githubusercontent.com/boyscp/scriscriptsc/main/bbn.lua"))()
        end
    )
    credits:Button(
        "传送工具",
        function()
            mouse = game.Players.LocalPlayer:GetMouse()
            tool = Instance.new("Tool")
            tool.RequiresHandle = false
            tool.Name = "Click Teleport"
            tool.Activated:connect(
                function()
                    local pos = mouse.Hit + Vector3.new(0, 2.5, 0)
                    pos = CFrame.new(pos.X, pos.Y, pos.Z)
                    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = pos
                end
            )
            tool.Parent = game.Players.LocalPlayer.Backpack
        end
    )
    credits:Button(
        "飞行",
        function()
            loadstring(game:HttpGet("https://pastebin.com/raw/gqv7PXAa"))()
        end
    )
    credits:Button(
        "光影V4",
        function()
            loadstring(game:HttpGet("https://pastebin.com/raw/zZCaYYte"))()
        end
    )
    credits:Button(
        "透视",
        function()
            loadstring(
                game:HttpGet(
                    "https://raw.githubusercontent.com/cool83birdcarfly02six/UNIVERSALESPLTX/main/README.md",
                    true
                )
            )()
        end
    )
    credits:Button(
        "人物旋转",
        function()
            loadstring(game:HttpGet("https://pastebin.com/raw/r97d7dS0", true))()
        end
    )
    credits:Button(
        "无限跳",
        function()
            loadstring(game:HttpGet("https://pastebin.com/raw/V5PQy3y0", true))()
        end
    )
    credits:Button(
        "飞车",
        function()
            loadstring(game:HttpGet("https://pastebin.com/raw/ZWXWa1eP"))()
        end
    )
    credits:Button(
        "电脑键盘",
        function()
            loadstring(
                game:HttpGet(
                    "https://raw.githubusercontent.com/advxzivhsjjdhxhsidifvsh/mobkeyboard/main/main.txt",
                    true
                )
            )()
        end
    )
    credits:Button(
        "炸房踢人无敌",
        function()
            loadstring(game:HttpGet("https://pastebin.com/raw/8nxMMAfj", true))()
        end
    )
    local creds = window:Tab("俄州", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "俄州指令脚本",
        function()
            loadstring(game:HttpGet("https://pastebin.com/raw/BPZycx9e", true))()
        end
    )
    credits:Button(
        "玩家控制",
        function()
            loadstring(game:HttpGet("https://pastebin.com/raw/WEj0kwT2"))()
        end
    )
    local creds = window:Tab("伐木大亨", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "伐木大亨1",
        function()
            loadstring(game:HttpGet("https://pastebin.com/raw/dwQDjMbp", true))()
        end
    )
    credits:Button(
        "伐木大亨2",
        function()
            loadstring(game:HttpGet("https://pastebin.com/raw/Q7seVBTV"))()
        end
    )
    credits:Button(
        "伐木大亨3",
        function()
            loadstring(
                game:HttpGet("https://raw.githubusercontent.com/darkxwin/darkxsourcethinkyoutousedarkx/main/darkx")
            )()
        end
    )
    local creds = window:Tab("爱德华食人列车", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "爱德华食人列车1",
        function()
            loadstring(
                game:HttpGet(
                    "https://raw.githubusercontent.com/GhostDuckyy/GhostDuckyy/main/Source/Edward%20the%20Man-Eating%20Train.lua"
                )
            )()
        end
    )
    local creds = window:Tab("鱿鱼游戏", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "鱿鱼游戏1",
        function()
            loadstring(game:HttpGet("https://raw.githubusercontent.com/LilFrench21/Hecta/main/Script/Squid%20Game"))()
        end
    )
    local creds = window:Tab("奇怪严格的办法", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "奇怪严格的爸爸",
        function()
            loadstring(game:HttpGet("https://raw.githubusercontent.com/yBloodz/Free-scripts/main/Weird%20Strict%20Dad"))(

            )
        end
    )
    local creds = window:Tab("造船寻宝", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "造船寻宝（复制别人船）",
        function()
            loadstring(
                game:HttpGet("https://raw.githubusercontent.com/max2007killer/auto-build-not-limit/main/autobuild.txt")
            )()
        end
    )
    credits:Button(
        "造船寻宝（刷钱）",
        function()
            loadstring(
                game:HttpGet("https://raw.githubusercontent.com/urmomjklol69/GoldFarmBabft/main/GoldFarm.lua", true)
            )()
        end
    )
    local creds = window:Tab("自然灾害", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "自然灾害1",
        function()
            loadstring(
                game:HttpGet(
                    "https://raw.githubusercontent.com/2dgeneralspam1/scripts-and-stuff/master/scripts/LoadstringUjHI6RQpz2o8",
                    true
                )
            )()
        end
    )
    credits:Button(
        "自然灾害2",
        function()
            loadstring(
                game:HttpGet(
                    "https://raw.githubusercontent.com/MrWitzbold/Natural-disaster-survival-GUI/main/main.lua",
                    true
                )
            )()
        end
    )
    credits:Button(
        "自然灾害3",
        function()
            loadstring(game:HttpGet("https://raw.githubusercontent.com/9NLK7/93qjoadnlaknwldk/main/main"))()
        end
    )
    local creds = window:Tab("鲨口求生", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "鲨口求生",
        function()
            loadstring(game:HttpGet("https://pastebin.com/raw/YYVLbzVg", true))()
        end
    )
    local creds = window:Tab("监狱人生", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "监狱人生1",
        function()
            loadstring(game:HttpGet("https://raw.githubusercontent.com/Denverrz/scripts/master/PRISONWARE_v1.3.txt"))()
        end
    )
    credits:Button(
        "监狱人生2",
        function()
            loadstring(
                game:HttpGet("https://raw.githubusercontent.com/i1nfinity/Project-X/master/Prison%20Breaker%20X", true)
            )()
        end
    )
    local creds = window:Tab("战争大亨", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "战争大亨1",
        function()
            loadstring(game:HttpGet("https://raw.githubusercontent.com/Nivex123456/War-Tycoon/main/Script"))()
        end
    )
    local creds = window:Tab("兵工厂", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "兵工厂1",
        function()
            loadstring(game:HttpGet("https://pastebin.com/raw/iZPW5vKH"))()
        end
    )
    local creds = window:Tab("举重模拟器", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "举重模拟器汉化版1",
        function()
            local UILibrary =
                loadstring(game:HttpGet("https://raw.githubusercontent.com/bloodball/-back-ups-for-libs/main/twink"))()
            local MainUI = UILibrary.Load("💪🏻举重模拟器")
            local FirstPage = MainUI.AddPage("首页")
            FirstPage.AddToggle(
                "自动举重",
                false,
                function(Value)
                    toggle = Value
                    while toggle do
                        wait()
                        local ohTable1 = {[1] = "GainMuscle"}
                        game:GetService("ReplicatedStorage").RemoteEvent:FireServer(ohTable1)
                    end
                end
            )
            FirstPage.AddToggle(
                "自动售卖",
                false,
                function(Value)
                    tog = Value
                    while tog do
                        wait()
                        local ohTable1 = {[1] = "SellMuscle"}
                        game:GetService("ReplicatedStorage").RemoteEvent:FireServer(ohTable1)
                    end
                end
            )
            FirstPage.AddButton(
                "显示商店界面",
                function()
                    game:GetService("Players").LocalPlayer.PlayerGui["Main_Gui"]["UpgradeMenu_Frame"].Visible = true
                end
            )
        end
    )
    local creds = window:Tab("越狱", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "越狱1",
        function()
            loadstring(game:GetObjects("rbxassetid://3762448307")[1].Source)()
        end
    )
    local creds = window:Tab("力量传奇", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "力量传奇传送和自动汉化",
        function()
            local MuscleLegends = Instance.new("ScreenGui")
            local balls = Instance.new("Frame")
            local TextButton = Instance.new("TextButton")
            local Frame = Instance.new("Frame")
            local TextButton_2 = Instance.new("TextButton")
            local MuscleLegends_2 = Instance.new("TextButton")
            local Frame_2 = Instance.new("Frame")
            local TextButton_3 = Instance.new("TextButton")
            local Frame_3 = Instance.new("Frame")
            local TextButton_4 = Instance.new("TextButton")
            local Frame_4 = Instance.new("Frame")
            local TextButton_5 = Instance.new("TextButton")
            local Frame_5 = Instance.new("Frame")
            local TextButton_6 = Instance.new("TextButton")
            local Frame_6 = Instance.new("Frame")
            MuscleLegends.Name = "MuscleLegends"
            MuscleLegends.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
            MuscleLegends.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
            balls.Name = "balls"
            balls.Parent = MuscleLegends
            balls.BackgroundColor3 = Color3.fromRGB(23, 25, 48)
            balls.BorderColor3 = Color3.fromRGB(11, 14, 25)
            balls.BorderSizePixel = 6
            balls.Position = UDim2.new(0.0587878786, 0, 0.263085395, 0)
            balls.Size = UDim2.new(0, 499, 0, 189)
            TextButton.Parent = balls
            TextButton.BackgroundColor3 = Color3.fromRGB(18, 21, 62)
            TextButton.BorderColor3 = Color3.fromRGB(6, 6, 25)
            TextButton.BorderSizePixel = 4
            TextButton.Position = UDim2.new(0.0237016678, 0, 0.122917295, 0)
            TextButton.Size = UDim2.new(0, 140, 0, 51)
            TextButton.Font = Enum.Font.Cartoon
            TextButton.Text = "自动锻炼"
            TextButton.TextColor3 = Color3.fromRGB(211, 183, 81)
            TextButton.TextSize = 25
            Frame.Parent = TextButton
            Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            Frame.BackgroundTransparency = 0.9
            Frame.BorderSizePixel = 0
            Frame.Position = UDim2.new(-0.00675659161, 0, 0.525454938, 0)
            Frame.Size = UDim2.new(0, 140, 0, 23)
            TextButton_2.Parent = balls
            TextButton_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
            TextButton_2.BackgroundTransparency = 0.8
            TextButton_2.Position = UDim2.new(-0.00193841383, 0, 0.922121644, 0)
            TextButton_2.Size = UDim2.new(0, 87, 0, 14)
            TextButton_2.Font = Enum.Font.SourceSans
            TextButton_2.Text = "汉化"
            TextButton_2.TextColor3 = Color3.fromRGB(255, 255, 255)
            TextButton_2.TextSize = 14
            MuscleLegends_2.Name = "Muscle Legends"
            MuscleLegends_2.Parent = balls
            MuscleLegends_2.BackgroundColor3 = Color3.fromRGB(31, 25, 63)
            MuscleLegends_2.BorderColor3 = Color3.fromRGB(0, 5, 29)
            MuscleLegends_2.BorderSizePixel = 4
            MuscleLegends_2.Position = UDim2.new(-0.0147496527, 0, -0.120468944, 0)
            MuscleLegends_2.Size = UDim2.new(0, 514, 0, 33)
            MuscleLegends_2.Font = Enum.Font.Cartoon
            MuscleLegends_2.Text = "力量传奇ato制作"
            MuscleLegends_2.TextColor3 = Color3.fromRGB(234, 199, 0)
            MuscleLegends_2.TextSize = 25
            Frame_2.Parent = MuscleLegends_2
            Frame_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            Frame_2.BackgroundTransparency = 0.95
            Frame_2.BorderSizePixel = 0
            Frame_2.Position = UDim2.new(0, 0, 0.515151978, 0)
            Frame_2.Size = UDim2.new(0, 513, 0, 15)
            TextButton_3.Parent = balls
            TextButton_3.BackgroundColor3 = Color3.fromRGB(18, 21, 62)
            TextButton_3.BorderColor3 = Color3.fromRGB(6, 6, 25)
            TextButton_3.BorderSizePixel = 4
            TextButton_3.Position = UDim2.new(0.358371019, 0, 0.122917295, 0)
            TextButton_3.Size = UDim2.new(0, 140, 0, 51)
            TextButton_3.Font = Enum.Font.Cartoon
            TextButton_3.Text = "传奇健身房"
            TextButton_3.TextColor3 = Color3.fromRGB(211, 183, 81)
            TextButton_3.TextSize = 25
            Frame_3.Parent = TextButton_3
            Frame_3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            Frame_3.BackgroundTransparency = 0.9
            Frame_3.BorderSizePixel = 0
            Frame_3.Position = UDim2.new(-0.00675659161, 0, 0.525454938, 0)
            Frame_3.Size = UDim2.new(0, 140, 0, 23)
            TextButton_4.Parent = balls
            TextButton_4.BackgroundColor3 = Color3.fromRGB(18, 21, 62)
            TextButton_4.BorderColor3 = Color3.fromRGB(6, 6, 25)
            TextButton_4.BorderSizePixel = 4
            TextButton_4.Position = UDim2.new(0.701056361, 0, 0.122917295, 0)
            TextButton_4.Size = UDim2.new(0, 140, 0, 51)
            TextButton_4.Font = Enum.Font.Cartoon
            TextButton_4.Text = "反对挂机"
            TextButton_4.TextColor3 = Color3.fromRGB(211, 183, 81)
            TextButton_4.TextSize = 25
            Frame_4.Parent = TextButton_4
            Frame_4.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            Frame_4.BackgroundTransparency = 0.9
            Frame_4.BorderSizePixel = 0
            Frame_4.Position = UDim2.new(-0.00675659161, 0, 0.525454938, 0)
            Frame_4.Size = UDim2.new(0, 140, 0, 23)
            TextButton_5.Parent = balls
            TextButton_5.BackgroundColor3 = Color3.fromRGB(18, 21, 62)
            TextButton_5.BorderColor3 = Color3.fromRGB(6, 6, 25)
            TextButton_5.BorderSizePixel = 4
            TextButton_5.Position = UDim2.new(0.0237016678, 0, 0.509160638, 0)
            TextButton_5.Size = UDim2.new(0, 140, 0, 51)
            TextButton_5.Font = Enum.Font.Cartoon
            TextButton_5.Text = "超级速度"
            TextButton_5.TextColor3 = Color3.fromRGB(211, 183, 81)
            TextButton_5.TextSize = 25
            Frame_5.Parent = TextButton_5
            Frame_5.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            Frame_5.BackgroundTransparency = 0.9
            Frame_5.BorderSizePixel = 0
            Frame_5.Position = UDim2.new(-0.00675659161, 0, 0.525454938, 0)
            Frame_5.Size = UDim2.new(0, 140, 0, 23)
            TextButton_6.Parent = balls
            TextButton_6.BackgroundColor3 = Color3.fromRGB(18, 21, 62)
            TextButton_6.BorderColor3 = Color3.fromRGB(6, 6, 25)
            TextButton_6.BorderSizePixel = 4
            TextButton_6.Position = UDim2.new(0.358371019, 0, 0.509160638, 0)
            TextButton_6.Size = UDim2.new(0, 140, 0, 51)
            TextButton_6.Font = Enum.Font.Cartoon
            TextButton_6.Text = "自动重生"
            TextButton_6.TextColor3 = Color3.fromRGB(211, 183, 81)
            TextButton_6.TextSize = 25
            Frame_6.Parent = TextButton_6
            Frame_6.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
            Frame_6.BackgroundTransparency = 0.9
            Frame_6.BorderSizePixel = 0
            Frame_6.Position = UDim2.new(-0.00675659161, 0, 0.525454938, 0)
            Frame_6.Size = UDim2.new(0, 140, 0, 23)
            local function HVDKG_fake_script()
                local script = Instance.new("LocalScript", TextButton)
                local Button = script.Parent
                local character = game.Players.LocalPlayer.character
                Button.MouseButton1Click:connect(
                    function()
                        while wait() do
                            local args = {[1] = "rep"}
                            game:GetService("Players").LocalPlayer.muscleEvent:FireServer(unpack(args))
                        end
                    end
                )
            end
            coroutine.wrap(HVDKG_fake_script)()
            local function HFRIPD_fake_script()
                local script = Instance.new("LocalScript", TextButton_3)
                local Button = script.Parent
                local character = game.Players.LocalPlayer.character
                Button.MouseButton1Click:connect(
                    function()
                        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
                            CFrame.new(
                            4195.27344,
                            990.221802,
                            -3876.88794,
                            0.999488235,
                            5.956108e-9,
                            -0.0319886059,
                            -4.2091868e-9,
                            0.99999994,
                            5.4678026e-8,
                            0.0319886059,
                            -5.4515407e-8,
                            0.999488235
                        )
                    end
                )
            end
            coroutine.wrap(HFRIPD_fake_script)()
            local function KYICYI_fake_script()
                local script = Instance.new("LocalScript", TextButton_4)
                local Button = script.Parent
                local Character = game.Workspace:FindFirstChild(game.Players.LocalPlayer.Name)
                Button.MouseButton1Click:connect(
                    function()
                        local vu = game:GetService("VirtualUser")
                        game:GetService("Players").LocalPlayer.Idled:connect(
                            function()
                                vu:Button2Down(Vector2.new(0, 0), workspace.CurrentCamera.CFrame)
                                wait(1)
                                vu:Button2Up(Vector2.new(0, 0), workspace.CurrentCamera.CFrame)
                            end
                        )
                    end
                )
            end
            coroutine.wrap(KYICYI_fake_script)()
            local function GGGSW_fake_script()
                local script = Instance.new("LocalScript", TextButton_5)
                local Button = script.Parent
                local Character = game.Workspace:FindFirstChild(game.Players.LocalPlayer.Name)
                Button.MouseButton1Click:connect(
                    function()
                        Character.Humanoid.WalkSpeed = 100
                    end
                )
            end
            coroutine.wrap(GGGSW_fake_script)()
            local function NUOF_fake_script()
                local script = Instance.new("LocalScript", TextButton_6)
                local Button = script.Parent
                local Character = game.Workspace:FindFirstChild(game.Players.LocalPlayer.Name)
                Button.MouseButton1Click:connect(
                    function()
                        while wait() do
                            game:GetService("ReplicatedStorage").rEvents.rebirthRemote:InvokeServer()
                        end
                    end
                )
            end
            coroutine.wrap(NUOF_fake_script)()
        end
    )
    local creds = window:Tab("bf", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "df {没中文}1",
        function()
            loadstring(game:HttpGet("https://raw.githubusercontent.com/REDzHUB/BloxFruits/main/redz9999"))()
        end
    )
    credits:Button(
        "df {中文}2",
        function()
            loadstring(
                game:HttpGet(
                    "https://raw.githubusercontent.com/XiaoYunCN/Xiao-Yun-UWU/main/%E6%B5%B7%E8%B4%BC%E7%8E%8Bbf.lua",
                    true
                )
            )()
        end
    )
    local creds = window:Tab("长途", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "长途没中文1",
        function()
            loadstring(game:HttpGet("https://scriptblox.com/raw/a-dusty-trip-FREE-CAR-Gui-14352"))()
        end
    )
    local creds = window:Tab("黑火药", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "黑火药1",
        function()
            loadstring(
                game:HttpGet(
                    "\104\116\116\112\115\58\47\47\114\97\119\46\103\105\116\104\117\98\117\115\101\114\99\111\110\116\101\110\116\46\99\111\109\47\119\104\97\116\116\102\97\47\78\79\78\69\47\109\97\105\110\47\115\99\114\105\112\116\46\108\117\97\63\116\111\107\101\110\61\71\72\83\65\84\48\65\65\65\65\65\65\67\78\77\81\90\51\86\53\52\89\52\52\86\52\67\69\82\85\50\65\71\75\85\90\81\80\89\85\88\81",
                    true
                )
            )()
        end
    )
    local creds = window:Tab("DOORS", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "DOORS汉化1",
        function()
            loadstring(
                game:HttpGet(
                    "\104\116\116\112\115\58\47\47\112\97\115\116\101\98\105\110\46\99\111\109\47\114\97\119\47\54\53\84\119\84\56\106\97"
                )
            )()
        end
    )
    local creds = window:Tab("蜂群", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "蜂群1",
        function()
            loadstring(
                game:HttpGet(
                    "https://raw.githubusercontent.com/Bear-script0/Bear-script1/main/%E8%9C%82%E7%BE%A4%E8%84%9A%E6%9C%AC"
                )
            )()
        end
    )
    local creds = window:Tab("监狱越狱计划", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "自动刷钱",
        function()
            loadstring(
                game:HttpGet(
                    "https://raw.githubusercontent.com/Bear-script0/Bear-script1/main/%E8%87%AA%E5%8A%A8%E5%88%B7%E9%92%B1"
                )
            )()
        end
    )
    local creds = window:Tab("极速传奇", "16060333448")
    local credits = creds:section("内容", true)
    credits:Button(
        "极速传奇1",
        function()
            loadstring(game:HttpGet("https://pastebin.com/raw/HCay9gcr"))()
        end
    )
end
